"""Reusable configuration components."""

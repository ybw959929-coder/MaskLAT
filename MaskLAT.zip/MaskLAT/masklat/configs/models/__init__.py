"""Model configurations for MaskLAT."""

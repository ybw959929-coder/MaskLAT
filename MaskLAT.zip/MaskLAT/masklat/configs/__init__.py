"""Configuration package for MaskLAT."""
